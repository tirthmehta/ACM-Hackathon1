<!DOCTYPE html>
<html lang="en">
<head>
<title>TROJAN HACKS</title>
<?php include("conn.php");?>
<?php include("head.php");?>
<?php
	session_start();
?>
<script src="js/jquery-2.1.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#login_message").hide(); 
	});
	function registered(){
		$("#login_message").show(); 
	}
	<?php
		function register(){
			include("conn.php");

			$conn = new mysqli($servername, $username, $password, $dbname); 
			if($conn->connect_error){
				die("connection_abort". $conn->connect_error);
			}

			$firstname = $_POST['firstname']; 
			$lastname = $_POST['lastname']; 
			$mobile = $_POST['mobile'];
			$email = $_POST['email']; 
			$pass = $_POST['password'];

			$sql = "INSERT INTO TROJANS.USER(FirstName, LastName, Email, Password, ContactNumber) VALUES ( '" . $firstname . "','" . $lastname . "','" . $email."','".$pass. "'," .$mobile.")"; 
			 
			if($conn->query($sql) === TRUE){
				echo '<div id = "login_message"> You have Successfully registered!</div>';
				echo "registered();";	
			}
			else{
				echo $conn->error; 
			}
		}

		if(isset($_POST['submit'])){
			register();
		}
	?>
</script>
</head>
<body>
	<?php include("navbar.php");?>
	<div class="wthree-main-content">
		<div class="container">
			<h5 class="title-w3">Login/Sign Up</h5>
			<div id="login_message" class="agileits-main">User Registered Successfully!</div> 
			<div class="w3-about-top">
				<div class="col-md-6 w3ls-about-top-right-grid">
					<div class="panel panel-default">
						<div class="panel-heading"><h4>Register</h4></div>
							<div class="panel-body">
								<form action="login.php" method="post" class="mod2">
								<ul>
											<li class="text">First Name :</li>
											<li class="agileits-main"><input name="firstname" type="text" required></li>
										</ul>
										<ul>
											<li class="text">Last Name :</li>
											<li class="agileits-main"><input name="lastname" type="text" required></li>
										</ul>
										<ul>
											<li class="text">Mobile no  :  </li>
											<li class="agileits-main"><input name="mobile" type="text" required></li>
										</ul>
										<ul>
											<li class="text">Email :  </li>
											<li class="agileits-main"><input name="email" type="email" required></li>
										</ul>
										<ul>
											<li class="text">Password  :  </li>
											<li class="agileits-main"><input name="password" type="password" required></li>
										</ul>
										<ul>
											<li class="text">Confirm Password  :  </li>
											<li class="agileits-main"><input name="conpass" type="password" required></li>
										</ul>
										<div class="clear"></div>
										<div class="agile-submit">
											<input type="submit" value="submit" name="submit">
										</div>
								</form>
							</div>
					</div>
				</div>
				<div class="col-md-6 w3ls-about-top-left-grid">
					<div class="panel panel-default">
						<div class="panel-heading"><h4>Login</h4></div>
							<div class="panel-body">
								<form action="checklogin.php" method="post" class="mod2">
										<ul>
											<li class="text">Email :  </li>
											<li class="agileits-main"><input name="email" type="email" required></li>
										</ul>
										<ul>
											<li class="text">Password  :  </li>
											<li class="agileits-main"><input name="password" type="password" required></li>
										<div class="clear"></div>
										<div class="agile-submit">
											<input type="submit" value="submit" name="loginSubmit">
										</div>
								</form>
							</div>
					</div>
				</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<?php include("footer.php");?>
<?php include("bottomscript.php");?>
</body>
</html>