<?php
	$servername = "localhost"; 
	$username = "root"; 
	$password = ""; 
	$dbname = "TROJANS";
	/*
	$conn = new mysqli($servername, $username, $password, $dbname); 
	if($conn->connect_error){
		die("connection_abort". $conn->connect_error);
	}
	
	
	echo 'Hi connected'; 

	$sql = "INSERT INTO TROJANS.USER(FirstName, LastName, Email, Password, ContactNumber) VALUES ('Shreyansh', 'kakadiya', 'sjfhahgkajh@usc.edu', 'fag', 9165161313)";


	if($conn->query($sql) === TRUE){
		echo ' DE'; 
	}
	else{
		echo $conn->error; 
	}
	
	echo '<br/>'; 

	$conn -> close(); 
	*/
?>