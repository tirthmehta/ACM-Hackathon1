
			<div class="copyright-wthree">
				<p>&copy; 2017 All Rights Reserved | Design by Kai and Shreyansh</p>
			</div>
