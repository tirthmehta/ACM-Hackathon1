<?php
session_start();
var_export($_POST);
var_export($_SESSION['reg']);

?>