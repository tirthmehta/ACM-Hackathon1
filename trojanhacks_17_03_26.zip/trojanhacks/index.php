<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
<title>My Connection</title>
<?php include("head.php");?>
</head>
<body>
<div class="banner" id="home">
		<!-- header -->
		<?php include("navbar.php");?>
	<!-- //header -->
	<!-- banner-text -->
		<div class="banner-text"> 
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider3">
					<li id="callbacks1_s0" class="" style="display: block; float: none; position: absolute; opacity: 0; z-index: 1; transition: opacity 500ms ease-in-out;">
						<div class="slider-info">
							<h3>Need help to improve skills?</h3>
							<h4>Request help in our platform</h4>
						
						</div>
					</li>
					<li id="callbacks1_s1" class="" style="display: block; float: none; position: absolute; opacity: 0; z-index: 1; transition: opacity 500ms ease-in-out;">
					
						<div class="slider-info">
							 <h3>Awesome skills to share</h3>
							<h4>Post in our platform and have fun by teaching</h4>
							
						   
						</div>
					</li>

				</ul>
				
			</div>
			<div class="clearfix"></div>	
		</div>
	</div>

<!--sign-up-section-->
	<div class="signup" id="signup">
		<div class="container">
		<div class="head-top-w3ls"><i class="fa fa-graduation-cap" aria-hidden="true"></i></div>
			<h5 class="title-w3">Post and Request To Learn.</h5>
			<p>Post any skills you have and request the skills you need. <br>Teaching benefits teachers as well as students.</p>
			<div class="button2">
			<h5><a href="login.php">Admission Now</a></h5>
				</div>
			</div>

 </div>
<!--//sign-up-section-->

<?php include("footer.php");?>
<?php include("bottomscript.php");?>
</body>
<script>
    $("#category-select").change(function(){
        if(this.value == "default"){
            $(".add-submit").hide();
        }else{
             $(".add-submit").show();
        }
        $(".checkbox-show").hide();
        console.log(this.value);
        selector = "."+this.value+"-checkbox";
        $(selector).show();
    })
    
    $("#learn-btn").click(function(){
        
    })
    
    
</script>
</html>