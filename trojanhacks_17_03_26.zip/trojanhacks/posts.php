<!DOCTYPE html>
<html lang="en">
<head>
<title>My Connection</title>
<?php include("head.php");?>
</head>
<body>
<!-- header -->
	<?php include("navbar.php");?>
<!-- //header -->
<div class="wthree-main-content">
		<!-- About-page -->
			<div class="container">
			<h5 class="title-w3">Any Generic Title</h5>
				Any Thing that we create will be here
				<div class="w3-about-top">
				<div class="col-md-6 w3ls-about-top-right-grid">
					Left Column
				</div>
				<div class="col-md-6 w3ls-about-top-left-grid">
					Right Column
				</div>
				<div class="clearfix"> </div>
			</div>
			</div>
			</div>
<!--sign-up-section-->
<!--//sign-up-section-->
<?php include("footer.php");?>
<?php include("bottomscript.php");?>
</body>
</html>