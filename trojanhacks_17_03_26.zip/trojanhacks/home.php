<?php
session_start();
include("conn.php");

$conn = new mysqli($servername, $username, $password, $dbname); 

if($conn->connect_error){
    die("connection_abort". $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Educative an education Category Flat Bootstrap Responsive website Template | Home</title>
<?php include("head.php");?>
<?php
    include("conn.php");

    $conn = new mysqli($servername, $username, $password, $dbname); 

    if($conn->connect_error){
        die("connection_abort". $conn->connect_error);
    }
    if(!empty($_POST['trojans'])) {
                foreach($_POST['trojans'] as $check) {
                    
                    $remail = $_SESSION['reg'][$check]['remail']; 
                    $aemail = $_SESSION['reg'][$check]['aemail']; 
                    $rid = $_SESSION['reg'][$check]['rid']; 
                    $aid = $_SESSION['reg'][$check]['aid']; 
                    $skill = $_SESSION['reg'][$check]['skill']; 
                    
                    
                    
                    $sql = "INSERT INTO TROJANS.session(rid, remail, aid, aemail, skill) VALUES ('{$rid}', '{$remail}', '{$aid}', '{$aemail}', '{$skill}')";
                    
                    if($conn->query($sql) === TRUE){
                    }
                    else{
                        echo $conn->error; 
                    }
                }
                
            }
    $conn->close();
?>
</head>
<body>
<!-- header -->
	<?php include("navbar.php");?>
<!-- //header -->
<div class="main-content">
    <!-- About-page -->
    <div class="container">
       
        <div class="w3-about-top">
           
            <div class="col-md-6 w3ls-about-top-right-grid mod2">  
                    <h4 style="margin-bottom: 30px"><i class="fa fa-list-alt"></i> Skills</h4>
           
                   <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Detail</th>
                        </tr>
                    </thead>
                    <tbody>


<?php


include("conn.php");
            $conn = new mysqli($servername, $username, $password, $dbname); 
            if($conn->connect_error){
                die("connection_abort". $conn->connect_error);
            }




                        $sql = "select DISTINCT Category, Details from TROJANS.skills where userid=\"".$_SESSION['id']."\";";
                        $result = $conn->query($sql);
                        if($result->num_rows > 0){
                            while($row=$result->fetch_assoc()){
                                echo '<tr>';
                                echo "<td>".$row['Category'] . "</td><td> " . $row['Details'] . " </td>"; 
                                echo '</tr>';
                            }
                        }

?>

                    </tbody>
                </table>
                
                <h4 style="margin-bottom: 30px"><i class="fa fa-envelope-o"></i>  Requests Received</h4>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Skills</th>
                            <th>Requester Email</th>
                        </tr>
                    </thead>
                    <tbody>


<?php


include("conn.php");
            $conn = new mysqli($servername, $username, $password, $dbname); 
            if($conn->connect_error){
                die("connection_abort". $conn->connect_error);
            }




                        $sql = "select *  from TROJANS.session where aid=\"".$_SESSION['id']."\";";
                        $result = $conn->query($sql);
                        if($result->num_rows > 0){
                            while($row=$result->fetch_assoc()){
                                echo '<tr>';
                                echo "<td>".$row['skill'] . "</td><td><a href='mailto:".$row['remail']."'>" . $row['remail'] . "</a></td>"; 
                                echo '</tr>';
                            }
                        }

?>





                        
                    
                    </tbody>
                </table>

                
                
        

            
         </div>
                
                
                
                
                
   
           
           <?php
            if(!isset($_POST['submit'])){
                
            ?>
            <div class="col-md-6 w3ls-about-top-left-grid mod2">
                <div id="learn-btn" class="btn btn-danger" style="color: #ffffff; margin-bottom: 20px; font-size: 18px; font-weight: bold">Learn A Skill <span class="fa fa-gavel"></span></div>
                
                <div class="skills-area">
                    <form action="home.php" method="post">
                        <div class="form-group">
                            <div>
                              <h4>Computer Science</h4>
                               <label class="radio-inline">
                                    <input type="radio" name="skill" value="C/C++"> C/C++
                               </label>
                               <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="HTML/CSS"> HTML/CSS
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Javascript"> Javascript
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Python"> Python
                                </label>
                                <br>
                            
                            </div>
                            <div>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Matlab"> Matlab
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Java"> Java
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Go"> Go
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Lua"> Lua
                                </label>
                                <br>
                            </div>
                            <div>
                               <h4>Music</h4>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Guitar"> Guitar
                               </label>
                               <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Piano"> Piano 
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Violin"> Violin 
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Sing"> Sing
                                </label>
                                <br>
                            </div>
                            
                            <div>
                               <h4>Dance</h4>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="AmericanRhythm"> American Rhythm
                               </label>
                               <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="ChaCha"> Cha Cha
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Modern"> Modern 
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Jazz"> Jazz
                                </label>
                                <br>
                            </div>
                            
                            <div>
                               <h4>Science</h4>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Mathematics"> Mathematics
                               </label>
                               <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Physic"> Physics
                                </label>
                                <br>
                                <label class="radio-inline">
                                    <input type="radio" name="skill" value="Engineering"> Engineering
                                </label>
                                <br>
                            </div>
                            
                            <div class="agile-submit">
                                <input name="submit" type="submit" value="submit">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php }else{ ?>
            <div class="col-md-6 w3ls-about-top-right-grid mod2">
                <form method="post" action="home.php">
                <?php
                global $array_ans;
                $array_ans = array(); 
                echo "<h4 style='margin-bottom: 30px'><i style='font-size: 18px;' class='fa fa-list-alt'></i>  Available Trojans</h4>";
                
                echo "<table class='table table-bordered table-hover'><thead><tr><th>Skill</th><th>Email</th><th>Connect</th></thead>";
                echo "<tbody>";
                
                
                $skill = $_POST['skill'];
                $sql = "SELECT user.Email, user.ID from user, skills where user.ID = skills.userid and skills.Details ='".$skill."' and userid not in (".$_SESSION['id']. ");";
                $result = $conn->query($sql);
                
                $i = 0;
                while($row = mysqli_fetch_assoc($result)){
                    $array_ans[$i]['remail'] = $_SESSION['email'];
                    $array_ans[$i]['aemail'] = $row['Email'];
                    $array_ans[$i]['rid'] = $_SESSION['id']; 
                    $array_ans[$i]['aid'] = $row['ID'];
                    $array_ans[$i]['skill'] = $skill; 
                    
                    echo "<tr>";
                    echo "<td>" . $skill . "</td>";
                    echo "<td>" . $row['Email'] . "</td>";
                    echo "<td>Click to connect <input type='checkbox' name='trojans[]' value=".$i."></td>";
                    echo "</tr>";
                    $_SESSION['reg'][$i] = $array_ans[$i]; 
                    $i++;
                }
                
                
                echo "</tbody></table>";
                echo "<div class='agile-submit'><input name='connect' type='submit' value='submit'></div>";
                
                ?>
                </form>
            </div>  
            <?php } ?>          
        
        
        
        
    
        
        
        </div>
    </div>
</div>



<?php include("footer.php");?>
<?php include("bottomscript.php");?>
<script>
    $("#learn-btn").click(function(){
        $(".skills-area").show();
    })
    var connect = function(session_id, row_id, session_email, row_email){
        console.log(session_id);
        var data = {
            sessionid: session_id,
            rowid: rowid,
            sessionemail: session_email,
            rowemail: row_email
        }
        console.log(data);
//        $.ajax({
//            type: "POST",
//            url: "home.php",
//            data: {session_id: session_id, }
//        })
    }
    
</script>
</body>
</html>