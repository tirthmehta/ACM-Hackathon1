		<header>
			<div class="container">

			<!-- navigation -->
			<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>				  
				<div class="w3-logo">
                    <a href="index.php"><img class="img-responsive float-left" src="./images/usc_trojans.png" alt="" width=50></a>
                    
				</div>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav">
					<li><a href="home.php">Home</a></li>
					<li><a href="editprofile.php">Profile</a></li>
					<li><a href="#">Posts</a></li>
					<li><a href="#">My Requests</a></li>
					<li><a href="#">My Connections</a></li>
					<?php 
                        if(isset($_SESSION["email"])){
                            echo '<li><a href="logout.php">Log Out</a></li>';
                        }
                        else{
                            echo '<li><a href="login.php">Log In</a></li>';
                        }
                        ?>
				  </ul>
				</div><!-- /.navbar-collapse -->
				 
			</nav>
			<div class="clearfix"></div>
		<!-- //navigation -->
			</div>
		</header>