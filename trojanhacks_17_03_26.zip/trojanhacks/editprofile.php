<?php
session_start();
    function add(){
            include("conn.php");
            $conn = new mysqli($servername, $username, $password, $dbname); 
            if($conn->connect_error){
                die("connection_abort". $conn->connect_error);
            }
            $id = $_SESSION['id'];
            //ß$sql="Delete from TROJANS.skills where userid=".$id.";";
           // $conn->query($sql);
            if(!empty($_POST['cs'])) {
                foreach($_POST['cs'] as $check) {
                    $id = $_SESSION['id'];
                     
                    $sql = "INSERT INTO TROJANS.skills(Category, Details, userid) VALUES ('Computer Science','" . $check."', " .$id .");";
                    if($conn->query($sql) === TRUE){
                    }
                    else{
                        echo $conn->error; 
                    }
                }
            }
            if(!empty($_POST['music'])) {
                foreach($_POST['music'] as $check) {
                    $id = $_SESSION['id'];
                     
                    $sql = "INSERT INTO TROJANS.skills(Category, Details, userid) VALUES ('Music','" . $check."', " .$id .");";
                    if($conn->query($sql) === TRUE){
                    }
                    else{
                        echo $conn->error; 
                    }
                }
            }

            if(!empty($_POST['dance'])) {
                foreach($_POST['dance'] as $check) {
                    $id = $_SESSION['id'];
                     
                    $sql = "INSERT INTO TROJANS.skills(Category, Details, userid) VALUES ('Dance','" . $check."', " .$id .");";
                    if($conn->query($sql) === TRUE){
                    }
                    else{
                        echo $conn->error; 
                    }
                }
            }

            if(!empty($_POST['science'])) {
                foreach($_POST['science'] as $check) {
                    $id = $_SESSION['id'];
                     
                    $sql = "INSERT INTO TROJANS.skills(Category, Details, userid) VALUES ('Science','" . $check."', " .$id .");";
                    if($conn->query($sql) === TRUE){
                    }
                    else{
                        echo $conn->error; 
                    }
                }
            }

            

            $conn->close(); 
        }
        if(isset($_POST['submit'])){
            add();
        }
if(isset($_GET['delete'])){
    include("conn.php");
   $conn = new mysqli($servername, $username, $password, $dbname); 
    if($conn->connect_error){
        die("connection_abort". $conn->connect_error);
    }

    $sql = "DELETE FROM skills WHERE id = " . $_GET['delete'].";";
    $result = $conn->query($sql); 
    header('Location: editprofile.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>My Connection</title>
<?php include("head.php");?>
<script type="text/javascript">
    function run(){
        alert("hello"); 
    }
    
</script>
</head>
<body>
<!-- header -->
	<?php include("navbar.php");?>
<!-- //header -->
<div class="wthree-main-content">
    <!-- About-page -->
    <div class="container">
        <h3 class="text-center">Profile Edit</h3>
        <div class="w3-about-top">
           
               <div class="col-md-6 w3ls-about-top-right-grid mod2">  
                    <h4 style="margin-bottom: 30px"><i class="fa fa-list-alt"></i> Skills</h4>
           
                   <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Detail</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>


<?php


include("conn.php");
$conn = new mysqli($servername, $username, $password, $dbname); 
if($conn->connect_error){
    die("connection_abort". $conn->connect_error);
}

$sql = "select DISTINCT id, Category, Details from TROJANS.skills where userid=\"".$_SESSION['id']."\";";
$result = $conn->query($sql);
if($result->num_rows > 0){
    while($row=$result->fetch_assoc()){
        echo '<tr>';
        echo "<td>".$row['Category'] . "</td><td> " . $row['Details'] . " </td><td><a href='?delete=". $row['id'] ."'>". "Delete</a></td>"; 
        echo '</tr>';
    }
}


?>





                        
                    
                    </tbody>
                </table>


                                 
                </div>
           
                <div class="col-md-6 w3ls-about-top-left-grid mod2">
                    
                       <h4 style="margin-bottom: 28px;margin-top:5px"><span class="fa fa-plus-circle"></span> Edit Skills</h4>
                         <form action="editprofile.php" class="form-inline" method="post">
                          <div class="form-group">
                           
                           <select class="form-control" name="" id="category-select">
                               <option value="default">Select a category First</option>
                                <option value="cs">Computer Science</option>
                                <option value="music">Music</option>
                                <option value="dance">Dance</option>
                                <option value="science">Science</option>
                            </select>
                            <div class="cs-checkbox checkbox-show">
                               <label class="checkbox-inline">
                                   <input type="checkbox" name="cs[]" value="C/C++"> C/C++
                               </label>
                               <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="HTML/CSS"> HTML/CSS
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="Javascript"> Javascript
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="Python"> Python
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="Matlab"> Matlab
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="Java"> Java
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="Go"> Go
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="cs[]" value="Lua"> Lua
                                </label>
                            </div>
                            <div class="music-checkbox checkbox-show">
                                <label class="checkbox-inline">
                                   <input type="checkbox" name="music[]" value="Guitar"> Guitar
                               </label>
                               <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="music[]" value="Piano">Piano 
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="music[]" value="Violin">Violin 
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="music[]" value="Sing">Sing
                                </label>
                            </div>
                            
                            <div class="dance-checkbox checkbox-show">
                                <label class="checkbox-inline">
                                   <input type="checkbox" name="dance[]" value="AmericanRhythm"> American Rhythm
                               </label>
                               <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="dance[]" value="ChaCha">Cha Cha
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="dance[]" value="Modern">Modern 
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="dance[]" value="Jazz">Jazz
                                </label>
                            </div>
                            
                            <div class="science-checkbox checkbox-show">
                                <label class="checkbox-inline">
                                   <input type="checkbox" name="science[]" value="Mathematics">Mathematics
                               </label>
                               <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="science[]" value="Physic"> Physics
                                </label>
                                <br>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="science[]" value="Engineering">Engineering
                                </label>
                            </div>
                            
                            
                           <div class="agile-submit add-submit">
                                <input name="submit" type="submit" value="Edit A Skill">
                            </div>
                       </div>
                        
                    </form>
                   </div>
  
            
        </div>
    </div>
</div>
<!--sign-up-section-->
<!--//sign-up-section-->
<?php include("footer.php");?>
<?php include("bottomscript.php");?>
</body>
<script>
    $("#category-select").change(function(){
        if(this.value == "default"){
            $(".add-submit").hide();
        }else{
             $(".add-submit").show();
        }
        $(".checkbox-show").hide();
        console.log(this.value);
        selector = "."+this.value+"-checkbox";
        $(selector).show();
    })
</script>
</html>