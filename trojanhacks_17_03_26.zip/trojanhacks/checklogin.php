<?php 
	include("conn.php");
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	$uemail=$_POST['email'];
	$sql = "select * from trojans.user where email=\"".$uemail."\";";
	$result = $conn->query($sql);
	if($result){
		$row = $result->fetch_assoc();
		if($_POST['password']==$row['Password']){
			echo "Hello	". $row['FirstName'];
			session_start();
			$_SESSION['email']=$row['Email'];
			$_SESSION['id']=$row['ID'];
			$_SESSION['firstname']=$row['FirstName'];
			$_SESSION['lastname']=$row['LastName'];
			$_SESSION['contact']=$row['ContactNumber'];
			header('Location:editprofile.php');
			exit;
		}
		else{
			echo "Wrong Password";
		}
	}
	$conn->close();
?>